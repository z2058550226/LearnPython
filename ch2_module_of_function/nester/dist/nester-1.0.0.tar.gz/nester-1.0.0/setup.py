from distutils.core import setup

setup(
        name = 'nester',
        version = '1.0.0',
        py_modules = ['nester'],
        author = 'hfpython',
        author_email = 'hfpython@headfirstlabs.com',
        url = 'http://www.headfristlabs.com',
        description = 'A simple printer of nested lists'
    )
