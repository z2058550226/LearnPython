from setuptools import setup, find_packages

setup(
    name="suikanester",
    py_modules=['suikanester'],
    packages=find_packages(),
    version='1.0.4',
    description="pypi upload test",
    author="suikajy",
    author_email='2058550226@qq.com',
    url='https://github.com/z2058550226/LearnPython',
    keywords=['tool']
)
